package vn.hust.aims.exception;

public class ExampleException extends RuntimeException {

  public ExampleException() {

  }

  public ExampleException(String message) {
    super(message);
  }
}