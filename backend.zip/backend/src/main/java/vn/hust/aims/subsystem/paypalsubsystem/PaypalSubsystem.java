package vn.hust.aims.subsystem.paypalsubsystem;

import vn.hust.aims.subsystem.PaymentSubsystem;

public class PaypalSubsystem implements PaymentSubsystem {

}
