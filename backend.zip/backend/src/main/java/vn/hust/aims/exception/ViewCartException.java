package vn.hust.aims.exception;

public class ViewCartException extends RuntimeException {

	private static final long serialVersionUID = 1091337136123906298L;

	public ViewCartException() {

	}

	public ViewCartException(String message) {
		super(message);
	}

}
