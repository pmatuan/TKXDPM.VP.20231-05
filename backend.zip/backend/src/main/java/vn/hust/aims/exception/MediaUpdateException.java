package vn.hust.aims.exception;

public class MediaUpdateException extends RuntimeException {

	private static final long serialVersionUID = 1091337136123906298L;

	public MediaUpdateException() {

	}

	public MediaUpdateException(String message) {
		super(message);
	}

}
