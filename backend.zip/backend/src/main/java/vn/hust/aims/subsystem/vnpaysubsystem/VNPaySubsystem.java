package vn.hust.aims.subsystem.vnpaysubsystem;

import vn.hust.aims.subsystem.PaymentSubsystem;

public class VNPaySubsystem implements PaymentSubsystem {

}
