package vn.hust.aims.repository.cart;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.hust.aims.entity.cart.CartMedia;

public interface CartMediaRepository extends JpaRepository<CartMedia, Long> {

}
