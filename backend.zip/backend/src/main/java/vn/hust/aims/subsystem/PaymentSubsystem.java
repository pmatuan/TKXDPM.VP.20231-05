package vn.hust.aims.subsystem;

public interface PaymentSubsystem {

}
