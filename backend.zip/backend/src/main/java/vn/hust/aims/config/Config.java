package vn.hust.aims.config;

public class Config {

}
